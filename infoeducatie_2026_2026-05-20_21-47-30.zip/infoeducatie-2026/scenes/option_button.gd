extends OptionButton


var ob: OptionButton

func _ready():
	ob = OptionButton.new()
	add_child(ob)
	ob.add_item("                                                  ")
	ob.add_item("Cazuri de nedeterminare")
	


	ob.set_item_metadata(0, "")
	ob.set_item_metadata(1, "https://resursesmmateblog.wordpress.com/wp-content/uploads/2022/11/limite_de_functii.pdf")
	

	ob.item_selected.connect(_on_option_selected)


func _on_option_selected(index):
	var link = ob.get_item_metadata(index)
	OS.shell_open(link)
